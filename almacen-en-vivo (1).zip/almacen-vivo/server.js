'use strict';
/* Turno en el Almacén · En vivo
   Servidor sin dependencias: solo necesita Node.js. Ejecuta:  node server.js */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = Number(process.env.PORT) || 3000;
// En internet, el anfitrión entra con esta clave. En la laptop local no hace falta.
const HOST_KEY = process.env.HOST_KEY || '';
const PUB = path.join(__dirname, 'public');

/* ---------- Datos ---------- */
const PRODUCTS = [
  { n: 'Tenis deportivos', sku: 'TD-101', peso: 'ligero', rot: 'alta' },
  { n: 'Mini refrigerador', sku: 'RF-220', peso: 'pesado', rot: 'baja' },
  { n: 'Celular', sku: 'CE-310', peso: 'ligero', rot: 'alta' },
  { n: 'Audífonos', sku: 'AU-415', peso: 'ligero', rot: 'media' },
  { n: 'Microondas', sku: 'MO-520', peso: 'pesado', rot: 'media' },
  { n: 'Balón de fútbol', sku: 'BA-601', peso: 'ligero', rot: 'alta' },
  { n: 'Pantalla de TV', sku: 'TV-880', peso: 'pesado', rot: 'alta' },
  { n: 'Mochila', sku: 'MC-905', peso: 'ligero', rot: 'baja' },
  { n: 'Cuadernos', sku: 'CU-120', peso: 'ligero', rot: 'media' },
  { n: 'Bocina bluetooth', sku: 'BC-250', peso: 'ligero', rot: 'baja' },
  { n: 'Cargador', sku: 'CG-130', peso: 'ligero', rot: 'media' },
  { n: 'Lavadora', sku: 'LV-990', peso: 'pesado', rot: 'baja' }
];

const STATIONS = [
  { short: 'Recibo', name: 'Recibo',
    goal: 'Llega un camión. Revisa cada caja contra la orden de compra antes de dejarla entrar al almacén.',
    rules: ['Acepta la caja si producto y cantidad coinciden con la orden y está en buen estado.', 'Rechaza cualquier caja con otro producto, otra cantidad o daños.'],
    why: 'Un error en el recibo se arrastra a todo el almacén: el inventario queda mal y después faltan o sobran productos.' },
  { short: 'Etiqueta', name: 'Nacionalización y etiquetado',
    goal: 'Las cajas vienen del extranjero y no tienen etiqueta. Elige la correcta para que el sistema sepa qué hay dentro.',
    rules: ['El código debe ser el del producto, según el catálogo.', 'La etiqueta debe estar en español para poder venderse en México.'],
    why: 'Sin la etiqueta correcta, nadie encuentra la caja. Y una etiqueta fuera de norma puede detener un envío completo.' },
  { short: 'Rack', name: 'Almacenaje',
    goal: 'Decide en qué lugar del rack se guarda cada caja. El lugar correcto ahorra pasos y evita accidentes.',
    rules: ['Rotación alta: zona A, cerca de la puerta. Media: zona B. Baja: zona C, al fondo.', 'Lo pesado va en el piso. Lo ligero va arriba.'],
    why: 'Si lo que más se vende está lejos, cada pedido cuesta más pasos y más tiempo. Si lo pesado está arriba, hay riesgo de accidente.' },
  { short: 'Surtido', name: 'Surtido de pedidos',
    goal: 'Llegan pedidos de clientes. Encuentra en el mapa del almacén el estante de cada producto.',
    rules: ['Usa el mapa de estantes para ubicar el producto.', 'Gana quien lo encuentre bien y más rápido.'],
    why: 'Aquí se gana o se pierde el tiempo. Por eso los productos tienen ubicaciones claras y las rutas se planean.' },
  { short: 'Envío', name: 'Embarque y envío',
    goal: 'Los pedidos ya están listos. Elige el transporte correcto según su destino.',
    rules: ['Cada paquete va al camión de su ciudad.', 'Los paquetes marcados como urgentes viajan en avión.'],
    why: 'Un paquete en el camión equivocado llega tarde o no llega, y el cliente es quien lo nota.' }
];
const LIMITS = [20, 20, 15, 15, 12];

/* ---------- Utilidades ---------- */
const rnd = n => Math.floor(Math.random() * n);
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const sample = (a, n) => shuffle(a).slice(0, n);

/* ---------- Preguntas ---------- */
function buildQuestions() {
  const qs = [];

  // Estación 0: Recibo
  const oc = sample(PRODUCTS, 3).map(p => ({ p, q: [6, 8, 10, 12][rnd(4)] }));
  shuffle(['ok', 'qty', 'prod', 'dmg']).forEach(kind => {
    const it = oc[rnd(3)];
    let p = it.p, q = it.q, dmg = false, explain;
    if (kind === 'ok') {
      explain = 'Producto y cantidad coinciden con la orden y la caja está en buen estado. Se acepta.';
    } else if (kind === 'prod') {
      const others = PRODUCTS.filter(x => !oc.some(o => o.p === x));
      p = others[rnd(others.length)];
      explain = p.n + ' no está en la orden de compra. Se rechaza.';
    } else if (kind === 'qty') {
      do { q = [4, 5, 7, 9, 11, 14, 16][rnd(7)]; } while (q === it.q);
      explain = 'La orden pide ' + it.q + ' piezas y llegaron ' + q + '. Se rechaza.';
    } else {
      dmg = true;
      explain = 'La caja llegó rota. Se rechaza y se avisa al proveedor.';
    }
    qs.push({
      station: 0, prompt: '¿Aceptas o rechazas esta caja?',
      card: { code: 'LLEGADA · ' + p.sku, name: p.n, tags: [{ t: q + ' pzas' }, { t: dmg ? 'Caja rota' : 'Caja en buen estado', red: dmg }] },
      ref: { title: 'Orden de compra', rows: oc.map(o => [o.p.n, o.q + ' pzas']) },
      options: [{ t: 'Aceptar' }, { t: 'Rechazar' }],
      correct: kind === 'ok' ? 0 : 1, explain
    });
  });

  // Estación 1: Etiquetado
  const pool = sample(PRODUCTS, 6);
  const lab = es => es ? 'Español · Hecho en China · Importa: Comercial MX' : 'English · Made in China · 1 unit';
  sample(pool, 4).forEach(p => {
    const o = pool.filter(x => x !== p)[rnd(5)];
    const opts = shuffle([
      { t: p.sku, s: lab(true), ok: true },
      { t: p.sku, s: lab(false) },
      { t: o.sku, s: lab(true) },
      { t: o.sku, s: lab(false) }
    ]);
    qs.push({
      station: 1, prompt: '¿Qué etiqueta le pegas a esta caja?',
      card: { code: 'IMPORTACIÓN · SIN ETIQUETA', name: p.n, tags: [{ t: 'Falta etiqueta' }] },
      ref: { title: 'Catálogo de códigos', chips: pool.map(x => x.n + ' · ' + x.sku) },
      options: opts.map(x => ({ t: x.t, s: x.s })),
      correct: opts.findIndex(x => x.ok),
      explain: 'Lleva el código ' + p.sku + ' y la etiqueta en español. Con otro código el sistema registra otro producto, y en inglés no cumple para venderse en México.'
    });
  });

  // Estación 2: Almacenaje
  const ZR = { alta: 'A', media: 'B', baja: 'C' };
  const ZN = { A: 'cerca de la puerta', B: 'centro', C: 'al fondo' };
  const all = [];
  ['A', 'B', 'C'].forEach(z => ['alto', 'piso'].forEach(l => all.push({ z, l })));
  sample(PRODUCTS, 4).forEach(p => {
    const z = ZR[p.rot], l = p.peso === 'pesado' ? 'piso' : 'alto';
    const right = all.find(c => c.z === z && c.l === l);
    const opts = shuffle([right].concat(sample(all.filter(c => c !== right), 3)));
    qs.push({
      station: 2, prompt: '¿Dónde va esta caja en el rack?',
      card: { code: 'POR ACOMODAR · ' + p.sku, name: p.n, tags: [{ t: 'Rotación ' + p.rot }, { t: p.peso === 'pesado' ? 'Pesado' : 'Ligero' }] },
      ref: { title: 'Reglas del rack', rows: [['Rotación alta', 'Zona A · puerta'], ['Rotación media', 'Zona B · centro'], ['Rotación baja', 'Zona C · fondo'], ['Pesado', 'Nivel piso'], ['Ligero', 'Nivel alto']] },
      options: opts.map(c => ({ t: 'Zona ' + c.z + ' · ' + ZN[c.z], s: c.l === 'piso' ? 'Nivel piso' : 'Nivel alto' })),
      correct: opts.indexOf(right),
      explain: p.n + ' tiene rotación ' + p.rot + ' y es ' + p.peso + ': va en la zona ' + z + ' (' + ZN[z] + ') ' + (l === 'piso' ? 'en el piso.' : 'en el nivel alto.')
    });
  });

  // Estación 3: Surtido
  const grid = shuffle(PRODUCTS).map((p, i) => ({ loc: 'ABCD'.charAt(Math.floor(i / 3)) + '-0' + (i % 3 + 1), name: p.n }));
  sample(grid, 4).forEach(t => {
    const locs = shuffle([t.loc].concat(sample(grid.filter(c => c !== t), 3).map(c => c.loc)));
    qs.push({
      station: 3, prompt: '¿En qué estante está este producto?',
      card: { code: 'PEDIDO #' + (1000 + rnd(9000)) + ' · 1 PZA', name: t.name, tags: [] },
      grid,
      options: locs.map(l => ({ t: l })),
      correct: locs.indexOf(t.loc),
      explain: t.name + ' está en el estante ' + t.loc + '.'
    });
  });

  // Estación 4: Envío
  const DEST = { cdmx: 'Ciudad de México', gdl: 'Guadalajara', mty: 'Monterrey' };
  const LANES = [['cdmx', 'Camión CDMX'], ['gdl', 'Camión Guadalajara'], ['mty', 'Camión Monterrey'], ['air', 'Avión urgente']];
  shuffle([true, false, false, false]).forEach(urgent => {
    const p = PRODUCTS[rnd(PRODUCTS.length)], d = ['cdmx', 'gdl', 'mty'][rnd(3)];
    const right = urgent ? 'air' : d;
    qs.push({
      station: 4, prompt: '¿En qué transporte sale este paquete?',
      card: { code: 'PEDIDO #' + (1000 + rnd(9000)), name: p.n, tags: [{ t: 'Destino: ' + DEST[d] }].concat(urgent ? [{ t: 'URGENTE', red: true }] : []) },
      options: LANES.map(l => ({ t: l[1] })),
      correct: LANES.findIndex(l => l[0] === right),
      explain: urgent ? 'Es urgente: lo urgente viaja en avión, sin importar el destino.' : 'Su destino es ' + DEST[d] + ', así que va en el camión de esa ciudad.'
    });
  });

  qs.forEach(q => { q.limit = LIMITS[q.station]; });
  return qs;
}

/* ---------- Estado del juego ---------- */
const players = new Map();   // id -> jugador
const hosts = new Set();     // respuestas SSE del anfitrión
let G = freshGame();

/* ---------- Modo libre: cada equipo juega las 5 estaciones a su ritmo ---------- */
const freeTeams = new Map();  // id -> { id, name, st: [null|{score,errors,secs} x5] }
const freeHosts = new Set();

function freeList() {
  return [...freeTeams.values()].map(t => ({
    id: t.id, name: t.name, st: t.st,
    total: t.st.reduce((a, x) => a + (x ? x.score : 0), 0),
    done: t.st.filter(Boolean).length,
    secs: t.st.reduce((a, x) => a + (x ? x.secs : 0), 0)
  })).sort((a, b) => b.total - a.total || a.secs - b.secs || a.name.localeCompare(b.name));
}
function freeSnapshot() {
  const list = freeList();
  const avg = [0, 1, 2, 3, 4].map(i => {
    const v = list.filter(t => t.st[i]).map(t => t.st[i].score);
    return v.length ? Math.round(v.reduce((a, b) => a + b, 0) / v.length) : null;
  });
  return {
    now: Date.now(), n: list.length,
    teams: list.slice(0, 40).map((t, i) => ({ pos: i + 1, name: t.name, scores: t.st.map(x => x ? x.score : null), total: t.total, done: t.done })),
    avg, names: STATIONS.map(x => x.name)
  };
}
function freeBroadcast() { const s = freeSnapshot(); freeHosts.forEach(r => send(r, s)); }

function freshGame() {
  return { phase: 'lobby', qs: buildQuestions(), qi: -1, si: -1, deadline: 0, qStart: 0, timer: null, stats: [], dist: [] };
}

function sortedPlayers() {
  return [...players.values()].sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
}
function isLastOfStation(i) {
  const q = G.qs[i], n = G.qs[i + 1];
  return !n || n.station !== q.station;
}
function qPublic(q, i) {
  const same = G.qs.filter(x => x.station === q.station);
  return { qi: i, station: q.station, idx: same.indexOf(q) + 1, nIn: same.length, limit: q.limit, prompt: q.prompt, card: q.card, ref: q.ref, grid: q.grid, options: q.options };
}
function onlinePlayers() { return [...players.values()].filter(p => p.res); }
function answeredCount() { return [...players.values()].filter(p => p.cur && p.cur.qi === G.qi).length; }

function byStation(p) {
  const out = STATIONS.map(() => [0, 0]);
  G.qs.forEach((q, i) => { out[q.station][1]++; if (p.answers[i] && p.answers[i].ok) { out[q.station][0]++; } });
  return out;
}

function stationStats() {
  return STATIONS.map((s, i) => {
    let c = 0, t = 0;
    G.stats.filter(x => x.station === i).forEach(x => { c += x.correct; t += x.total; });
    return { name: s.name, pct: t ? Math.round(100 * c / t) : null };
  });
}

function snapshot(player) {
  const s = {
    phase: G.phase, now: Date.now(), total: G.qs.length, nPlayers: players.size, nOnline: onlinePlayers().length,
    stations: STATIONS.map(x => ({ short: x.short, name: x.name, goal: x.goal, rules: x.rules, why: x.why }))
  };
  if (G.phase === 'lobby') {
    s.teams = [...players.values()].slice(-60).map(p => ({ name: p.name, online: !!p.res }));
  }
  if (G.phase === 'intro') { s.si = G.si; }
  if (G.phase === 'question' || G.phase === 'reveal') {
    const q = G.qs[G.qi];
    s.q = qPublic(q, G.qi);
    s.deadline = G.deadline;
    s.answered = answeredCount();
    if (G.phase === 'reveal') {
      s.correct = q.correct;
      s.explain = q.explain;
      s.last = isLastOfStation(G.qi);
      s.dist = G.dist;
      const sorted = sortedPlayers();
      s.top = sorted.slice(0, 5).map((p, i) => ({ pos: i + 1, name: p.name, score: p.score, delta: p.answers[G.qi] ? p.answers[G.qi].pts : 0 }));
    }
  }
  if (G.phase === 'final') {
    s.ranking = sortedPlayers().slice(0, 30).map((p, i) => ({ pos: i + 1, name: p.name, score: p.score }));
    s.stationStats = stationStats();
  }
  if (player) {
    const sorted = sortedPlayers();
    const a = player.answers[G.qi];
    s.me = {
      id: player.id, name: player.name, score: player.score,
      rank: sorted.indexOf(player) + 1, of: sorted.length, streak: player.streak,
      choice: player.cur && player.cur.qi === G.qi ? player.cur.c : null,
      result: G.phase === 'reveal' && a ? { ok: a.ok, pts: a.pts, c: a.c } : null,
      byStation: byStation(player)
    };
  }
  return s;
}

function send(res, obj) {
  try { res.write('data: ' + JSON.stringify(obj) + '\n\n'); } catch (e) { /* conexión cerrada */ }
}
function broadcast() {
  hosts.forEach(r => send(r, snapshot(null)));
  players.forEach(p => { if (p.res) { send(p.res, snapshot(p)); } });
}

function startQuestion(i) {
  G.qi = i;
  G.phase = 'question';
  G.qStart = Date.now();
  const lim = G.qs[i].limit * 1000;
  G.deadline = G.qStart + lim;
  clearTimeout(G.timer);
  G.timer = setTimeout(closeQuestion, lim + 400);
  broadcast();
}

function closeQuestion() {
  if (G.phase !== 'question') { return; }
  clearTimeout(G.timer);
  const q = G.qs[G.qi];
  const dist = q.options.map(() => 0);
  let correct = 0;
  players.forEach(p => {
    const a = p.cur && p.cur.qi === G.qi ? p.cur : null;
    if (a) {
      p.score += a.pts;
      p.streak = a.ok ? p.streak + 1 : 0;
      p.answers[G.qi] = { ok: a.ok, pts: a.pts, c: a.c };
      dist[a.c]++;
      if (a.ok) { correct++; }
    } else {
      p.streak = 0;
      p.answers[G.qi] = { ok: false, pts: 0, c: null };
    }
  });
  G.dist = dist;
  G.stats.push({ station: q.station, correct, total: players.size });
  G.phase = 'reveal';
  broadcast();
}

function advance() {
  if (G.phase === 'lobby') {
    if (players.size === 0) { return; }
    G.si = 0; G.phase = 'intro'; broadcast();
  } else if (G.phase === 'intro') {
    startQuestion(G.qs.findIndex(q => q.station === G.si));
  } else if (G.phase === 'question') {
    closeQuestion();
  } else if (G.phase === 'reveal') {
    const n = G.qi + 1;
    if (n >= G.qs.length) { G.phase = 'final'; broadcast(); }
    else if (G.qs[n].station !== G.si) { G.si = G.qs[n].station; G.phase = 'intro'; broadcast(); }
    else { startQuestion(n); }
  }
}

function resetGame() {
  clearTimeout(G.timer);
  G = freshGame();
  players.forEach(p => { p.score = 0; p.streak = 0; p.answers = []; p.cur = null; });
  broadcast();
}

/* ---------- HTTP ---------- */
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };

function isLocal(req) {
  const a = req.socket.remoteAddress || '';
  return a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1';
}
function isHostReq(req, key) {
  return isLocal(req) || (HOST_KEY !== '' && key === HOST_KEY);
}
function sendText(res, code, text, type) {
  res.writeHead(code, { 'Content-Type': type || 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(text);
}
function sendJson(res, code, obj) { sendText(res, code, JSON.stringify(obj), 'application/json; charset=utf-8'); }
function sendFile(res, name) {
  const file = path.join(PUB, path.basename(name));
  fs.readFile(file, (err, buf) => {
    if (err) { return sendText(res, 404, 'No encontrado'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(buf);
  });
}
function readJson(req, cb) {
  let body = '';
  req.on('data', c => { body += c; if (body.length > 10000) { req.destroy(); } });
  req.on('end', () => { let o = {}; try { o = JSON.parse(body || '{}'); } catch (e) { o = {}; } cb(o); });
}

function lanUrls() {
  const list = [];
  const ifs = os.networkInterfaces();
  Object.keys(ifs).forEach(k => (ifs[k] || []).forEach(i => {
    if (i.family === 'IPv4' && !i.internal) { list.push(i.address); }
  }));
  const score = ip => /^192\.168\./.test(ip) ? 0 : /^10\./.test(ip) ? 1 : /^172\.(1[6-9]|2\d|3[01])\./.test(ip) ? 2 : 3;
  return list.sort((a, b) => score(a) - score(b)).map(ip => 'http://' + ip + ':' + PORT);
}

function openStream(req, res, u) {
  const role = u.searchParams.get('role');
  const id = u.searchParams.get('id');
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', 'Connection': 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.write('retry: 2000\n\n');
  if (role === 'freehost') {
    if (!isHostReq(req, u.searchParams.get('key') || '')) { return res.end(); }
    freeHosts.add(res);
    send(res, freeSnapshot());
    req.on('close', () => freeHosts.delete(res));
    return;
  }
  if (role === 'host') {
    if (!isHostReq(req, u.searchParams.get('key') || '')) { return res.end(); }
    hosts.add(res);
    send(res, snapshot(null));
    req.on('close', () => hosts.delete(res));
    return;
  }
  const p = players.get(id);
  if (!p) { send(res, { phase: 'unknown' }); return res.end(); }
  if (p.res && p.res !== res) { try { p.res.end(); } catch (e) { /* ya cerrada */ } }
  p.res = res;
  send(res, snapshot(p));
  broadcastHostOnly();
  req.on('close', () => { if (p.res === res) { p.res = null; broadcastHostOnly(); } });
}
function broadcastHostOnly() { hosts.forEach(r => send(r, snapshot(null))); }

function cleanName(s) {
  s = String(s || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 20);
  return s || 'Equipo';
}

const server = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://localhost');
  const p = u.pathname;

  if (req.method === 'GET') {
    if (p === '/') { return sendFile(res, 'play.html'); }
    if (p === '/host') { return sendFile(res, 'host.html'); }
    if (p === '/libre') { return sendFile(res, 'libre.html'); }
    if (p === '/marcador') { return sendFile(res, 'marcador.html'); }
    if (p === '/api/free/board') {
      const id = u.searchParams.get('id') || '';
      const list = freeList();
      const idx = list.findIndex(t => t.id === id);
      return sendJson(res, 200, {
        top: list.slice(0, 8).map((t, i) => ({ pos: i + 1, name: t.name, total: t.total, done: t.done })),
        me: idx >= 0 ? { pos: idx + 1, of: list.length, total: list[idx].total } : null
      });
    }
    if (p === '/api/hostcheck') { return sendJson(res, 200, { ok: isHostReq(req, u.searchParams.get('key') || '') }); }
    if (p === '/events') { return openStream(req, res, u); }
    if (p === '/api/info') { return sendJson(res, 200, { urls: lanUrls(), port: PORT }); }
    if (/^\/[\w.-]+$/.test(p) && ['/base.css', '/common.js', '/qrcode.js'].indexOf(p) >= 0) { return sendFile(res, p.slice(1)); }
    return sendText(res, 404, 'No encontrado');
  }

  if (req.method === 'POST') {
    return readJson(req, body => {
      if (p === '/api/join') {
        let pl = body.id ? players.get(body.id) : null;
        if (!pl) {
          let name = cleanName(body.name), n = name, k = 2;
          while ([...players.values()].some(x => x.name.toLowerCase() === n.toLowerCase())) { n = name + ' ' + k++; }
          const id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
          pl = { id, name: n, score: 0, streak: 0, answers: [], cur: null, res: null };
          players.set(id, pl);
          broadcastHostOnly();
        }
        return sendJson(res, 200, { id: pl.id, name: pl.name });
      }
      if (p === '/api/answer') {
        const pl = players.get(body.id);
        const c = Number(body.choice);
        if (!pl || G.phase !== 'question') { return sendJson(res, 200, { ok: false }); }
        const q = G.qs[G.qi];
        if (pl.cur && pl.cur.qi === G.qi) { return sendJson(res, 200, { ok: false }); }
        if (!Number.isInteger(c) || c < 0 || c >= q.options.length) { return sendJson(res, 400, { ok: false }); }
        if (Date.now() > G.deadline + 300) { return sendJson(res, 200, { ok: false }); }
        const ok = c === q.correct;
        let pts = 0;
        if (ok) {
          const frac = Math.min(1, Math.max(0, (Date.now() - G.qStart) / (q.limit * 1000)));
          pts = Math.round(1000 * (1 - frac / 2)) + 50 * Math.min(pl.streak, 5);
        }
        pl.cur = { qi: G.qi, c, ok, pts };
        send(pl.res || { write() {} }, snapshot(pl));
        broadcastHostOnly();
        const online = onlinePlayers();
        if (online.length && online.every(x => x.cur && x.cur.qi === G.qi)) { setTimeout(closeQuestion, 500); }
        return sendJson(res, 200, { ok: true });
      }
      if (p === '/api/free/join') {
        let t = body.id ? freeTeams.get(body.id) : null;
        if (!t) {
          const name = cleanName(body.name);
          let n = name, k = 2;
          while ([...freeTeams.values()].some(x => x.name.toLowerCase() === n.toLowerCase())) { n = name + ' ' + k++; }
          const id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
          t = { id, name: n, st: [null, null, null, null, null] };
          freeTeams.set(id, t);
          freeBroadcast();
        }
        return sendJson(res, 200, { id: t.id, name: t.name });
      }
      if (p === '/api/free/result') {
        const t = freeTeams.get(body.id);
        const i = Number(body.station), score = Number(body.score), errors = Number(body.errors), secs = Number(body.secs);
        if (!t) { return sendJson(res, 200, { ok: false, unknown: true }); }
        if (!Number.isInteger(i) || i < 0 || i > 4 || t.st[i]) { return sendJson(res, 200, { ok: false }); }
        if (!Number.isFinite(score) || score < 0 || score > 100 || !Number.isFinite(errors) || errors < 0 || errors > 999 || !Number.isFinite(secs) || secs < 0 || secs > 3600) { return sendJson(res, 400, { ok: false }); }
        t.st[i] = { score: Math.round(score), errors: Math.round(errors), secs: Math.round(secs) };
        freeBroadcast();
        return sendJson(res, 200, { ok: true });
      }
      if (p === '/api/free/reset') {
        if (!isHostReq(req, String(body.key || ''))) { return sendJson(res, 403, { ok: false }); }
        freeTeams.clear();
        freeBroadcast();
        return sendJson(res, 200, { ok: true });
      }
      if (p === '/api/host') {
        if (!isHostReq(req, String(body.key || ''))) { return sendJson(res, 403, { ok: false }); }
        if (body.action === 'next') { advance(); }
        if (body.action === 'reset') { resetGame(); }
        return sendJson(res, 200, { ok: true });
      }
      return sendText(res, 404, 'No encontrado');
    });
  }
  sendText(res, 405, 'Método no permitido');
});

setInterval(() => { hosts.forEach(r => { try { r.write(': ping\n\n'); } catch (e) { /* cerrada */ } }); players.forEach(p => { if (p.res) { try { p.res.write(': ping\n\n'); } catch (e) { /* cerrada */ } } }); }, 15000);

server.listen(PORT, '0.0.0.0', () => {
  const urls = lanUrls();
  console.log('\n  Turno en el Almacén · En vivo\n');
  console.log('  Modo Kahoot (todos responden a la vez):');
  console.log('     En esta laptop abre:  http://localhost:' + PORT + '/host   (pantalla que se proyecta)');
  console.log('  Modo libre (cada equipo a su ritmo):');
  console.log('     En esta laptop abre:  http://localhost:' + PORT + '/marcador   (pantalla que se proyecta)');
  console.log('  Los equipos entran escaneando el QR que aparece en pantalla.');
  if (urls.length) { console.log('     Dirección para celulares: ' + urls.join('  o  ')); }
  else { console.log('     No se encontró red. Conecta la laptop a la misma wifi que los celulares.'); }
  console.log('\n  Para detener el servidor presiona Ctrl+C.\n');
});
