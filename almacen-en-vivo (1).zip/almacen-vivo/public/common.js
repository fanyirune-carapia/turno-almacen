/* Piezas de interfaz compartidas por la pantalla del anfitrión y los celulares */
(function(w){
  'use strict';
  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  var LET=['A','B','C','D'];
  var SHORT=['Recibo','Etiqueta','Rack','Surtido','Envío'];

  function track(i){
    return SHORT.map(function(s,k){return '<div class="'+(k<i?'done':k===i?'now':'')+'">'+s+'</div>';}).join('');
  }
  function card(q){
    if(!q.card){return '';}
    return '<div class="ticket"><div class="code">'+esc(q.card.code)+'</div><div class="name">'+esc(q.card.name)+'</div>'+
      (q.card.tags||[]).map(function(t){return '<span class="tag'+(t.red?' red':'')+'">'+esc(t.t)+'</span>';}).join('')+'</div>';
  }
  function ref(q){
    if(!q.ref){return '';}
    var r=q.ref,body='';
    if(r.rows){body=r.rows.map(function(x){return '<div><span>'+esc(x[0])+'</span><b class="mono">'+esc(x[1])+'</b></div>';}).join('');}
    if(r.chips){body='<div class="chips">'+r.chips.map(function(c){return '<span class="chip">'+esc(c)+'</span>';}).join('')+'</div>';}
    return '<div class="oc"><h3>'+esc(r.title)+'</h3>'+body+'</div>';
  }
  function grid(q){
    if(!q.grid){return '';}
    return '<div class="aisle">'+q.grid.map(function(c){return '<div class="cell"><span class="loc">'+esc(c.loc)+'</span><span>'+esc(c.name)+'</span></div>';}).join('')+'</div>';
  }
  function optInner(o,i){
    return '<span class="k">'+LET[i]+'</span><span>'+esc(o.t)+(o.s?'<small>'+esc(o.s)+'</small>':'')+'</span>';
  }
  w.UI={esc:esc,track:track,card:card,ref:ref,grid:grid,optInner:optInner,LET:LET};
})(window);
